from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# List of predefined chatbot responses (could be extended)
responses = {
    "admission_process": "The admission process involves filling out an online form, submitting documents, and completing an interview.",
    "eligibility": "To be eligible, you must have completed your 12th grade with a minimum of 50% marks in any stream.",
    "fee_structure": "The fee structure varies based on the course, but typically ranges from $500 to $2000 per semester.",
    "courses_offered": "We offer undergraduate, postgraduate, and diploma courses in various disciplines like Engineering, Arts, and Science.",
    "default": "Sorry, I didn't quite catch that. Can you please rephrase your question?"
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    user_message = request.form["message"]
    
    # Simple logic to get the response
    if "admission" in user_message.lower():
        return jsonify({"response": responses["admission_process"]})
    elif "eligibility" in user_message.lower():
        return jsonify({"response": responses["eligibility"]})
    elif "fee" in user_message.lower():
        return jsonify({"response": responses["fee_structure"]})
    elif "courses" in user_message.lower():
        return jsonify({"response": responses["courses_offered"]})
    else:
        return jsonify({"response": responses["default"]})

if __name__ == "__main__":
    app.run(debug=True)
